Title: Meter Analog Resizeable (updated again)
Description: Rainy week-end project.Resizeable meter with several property options. Sorry only one range though (0 to 100).update: added gradient bkgd so it can look like its backlit.update:made a couple of changes,one thanks to Emad.Also added two more ucmeters I was playing around with.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=72691&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
