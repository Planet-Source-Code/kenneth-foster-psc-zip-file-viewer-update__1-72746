KBandwidth monitor. A graphic network traffic monitor.

Counts Upload/Download network traffic. 
Shows graphically these stats using two speed dial style metters.
All in vb6. Small executable (70k) no need to install, vbruntimes, activex/ocx's


Killerian@hotmail.com
