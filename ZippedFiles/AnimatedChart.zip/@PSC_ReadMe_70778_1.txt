Title: Animated Chart
Description: UPDATE : 2009/11/06-----------------------------
Finally, I've update this little control and now you can have it in your EXE, no need to compile as an ocx or ..., some bugs about speed of chart were fixed,
Sorry for the delay and hope you enjoy,
-----------------------------------------------
This is My Animated Chart Version 2, with 4 new themes: PersianGulf, Sky, Neon and Normal.
Some changes in animating mode, now all bars grow simultaneously instead of one by one, some bugs fixed and now you can show bars descriptions and ...
This is the first Animating Chart in PSC and I can't found any commercial instance (of course you can found some Flash Maker),
Hope you like it, I', waiting for your feedbacks and if you like this please vote,
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=70778&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
